<template>
helooodsf
<h1>{{ $store.state.count }}</h1>

  


</template>

<script>
export default {
}

</script>


<style>




</style>