<template>

  




 
</template>

<script>
export default {
    props: ["friends"]



}
    







</script>




<style>



</style>