<template>
    efefrgrgregregregrgrgregs
<h1>USERS</h1>

</template>ewrewrerewrggrregregregre
<script>
export default {

  props: ['users']
}



</script>

<style scoped>

</style>
