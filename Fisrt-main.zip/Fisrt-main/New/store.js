import { createStore } from "vuex"

const store = createStore({
    state () {
      return {
        count: 34
      }
    }
})

export default store