<template>
    <WelcomeItem />
    <MainBlock />



</template>

 
<script>
import WelcomeItem from './WelcomeItem.vue'
import MainBlock from './MainBlock.vue'
export default {
    components: {WelcomeItem, MainBlock}

}

</script>

<style>





</style>