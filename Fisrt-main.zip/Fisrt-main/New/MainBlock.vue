<template>
    <div class="WgoleWolrd">

      
    </div>
</template>

<script>
export default {
    data() {
        return {
            WaterProect: '',
        }
    },
    methods: {
        WaterFunction () {

        }
    }

}

</script>

<style>


</style>